/* طبقة فوق طبقة — منطق التطبيق
 * الطبقات تُخزَّن كبيانات بسيطة (بلا صور)، والصور في خريطة منفصلة،
 * لذلك يمكن أخذ لقطة من الحالة للتراجع/الإعادة بسهولة.
 */
(function () {
  'use strict';

  /* ---------- أدوات عامة ---------- */
  var $ = function (id) { return document.getElementById(id); };
  var $$ = function (sel) { return Array.prototype.slice.call(document.querySelectorAll(sel)); };
  function clamp(v, a, b) { return Math.min(b, Math.max(a, v)); }
  function newCanvas(w, h) { var c = document.createElement('canvas'); c.width = w; c.height = h; return c; }
  function setStatus(msg, kind) {
    var el = $('status');
    el.textContent = msg || '';
    el.className = 'status' + (kind ? ' ' + kind : '');
  }
  function fmtSize(n) {
    return n >= 1048576 ? (n / 1048576).toFixed(1) + ' MB' : Math.max(1, Math.round(n / 1024)) + ' KB';
  }
  function isImageFile(f) { return !!f && (!f.type || f.type.indexOf('image/') === 0); }

  var IS_IOS = /iPad|iPhone|iPod/.test(navigator.userAgent) || (navigator.platform === 'MacIntel' && navigator.maxTouchPoints > 1);
  var COARSE = !!(window.matchMedia && window.matchMedia('(pointer: coarse)').matches);
  var MAX_SIDE = IS_IOS ? 16384 : 32767;
  var MAX_AREA = IS_IOS ? 16777216 : (COARSE ? 100000000 : 268435456);
  var SNAP = 0.006;      // مسافة الالتصاق بالمركز (نسبة من الخلفية)

  var FILTER_OK = false;
  (function () {
    try {
      var a = newCanvas(5, 1), ax = a.getContext('2d'); ax.fillStyle = '#fff'; ax.fillRect(2, 0, 1, 1);
      var b = newCanvas(5, 1), bx = b.getContext('2d'); bx.filter = 'blur(1px)'; bx.drawImage(a, 0, 0);
      FILTER_OK = bx.getImageData(1, 0, 1, 1).data[3] > 0;
    } catch (e) { FILTER_OK = false; }
  })();

  /* ---------- ثوابت ---------- */
  var LAYER_DEFAULTS = {
    cx: 0.5, cy: 0.5, wf: 0.35, rot: 0, op: 1, flip: false, blend: 'source-over',
    visible: true, locked: false, feather: 0, match: 0, soft: 0, shadow: 0, grain: 0
  };
  var ENH = ['feather', 'match', 'soft', 'shadow', 'grain'];
  var AUTO = { feather: 15, match: 65, soft: 12, shadow: 30, grain: 20 };
  var PRESETS = [
    { id: 'clean', label: 'نظيف (بدون تأثيرات)', op: 1, blend: 'source-over', feather: 0, match: 0, soft: 0, shadow: 0, grain: 0 },
    { id: 'blend', label: 'مدمج مع الخلفية', op: 0.9, blend: 'multiply', feather: 15, match: 65, soft: 12, shadow: 0, grain: 20 },
    { id: 'sticker', label: 'ملصق بظل', op: 1, blend: 'source-over', feather: 0, match: 0, soft: 0, shadow: 35, grain: 0 },
    { id: 'ink', label: 'حبر على ورق', op: 0.85, blend: 'multiply', feather: 25, match: 40, soft: 25, shadow: 0, grain: 45 },
    { id: 'light', label: 'ضوء وتوهج', op: 0.8, blend: 'screen', feather: 30, match: 30, soft: 10, shadow: 0, grain: 10 },
    { id: 'vintage', label: 'ورق قديم', op: 0.75, blend: 'overlay', feather: 20, match: 70, soft: 20, shadow: 10, grain: 35 }
  ];
  var FORMAT_NOTES = {
    png: 'يحفظ كل بكسل كما هو دون أي فقد، وقد يكون حجم الملف كبيرًا.',
    jpeg: 'أصغر حجمًا، لكنه يضغط الصورة قليلًا ولا يدعم الشفافية.',
    webp: 'أصغر حجمًا مع جودة عالية جدًا. بعض المتصفحات تحفظه بصيغة PNG تلقائيًا.'
  };
  var MIME = { png: 'image/png', jpeg: 'image/jpeg', webp: 'image/webp' };
  var EXT = { 'image/png': 'png', 'image/jpeg': 'jpg', 'image/webp': 'webp' };

  /* ---------- الحالة ---------- */
  var images = new Map();          // id -> صورة (src, w, h, name, stats, thumb)
  var imgSeq = 0;
  var layerSeq = 0;
  var state = {
    baseId: null,
    layers: [],                    // من الأسفل إلى الأعلى
    activeId: null,
    mult: 1, format: 'png',
    frame: false, fine: false, guides: true, peek: false
  };
  var history = { stack: [], idx: -1 };
  var downloads = null;
  var pw = 0, ph = 0;              // أبعاد المعاينة
  var snap = { x: false, y: false };

  function baseImg() { return state.baseId ? images.get(state.baseId) : null; }
  function imgOf(l) { return images.get(l.imgId); }
  function findLayer(id) {
    for (var i = 0; i < state.layers.length; i++) if (state.layers[i].id === id) return state.layers[i];
    return null;
  }
  function active() { return findLayer(state.activeId); }
  function displayName(im) { return im.sample ? 'صورة مثال' : im.name; }

  /* ---------- التراجع والإعادة ---------- */
  // نُسجّل لقطة بعد انتهاء كل فعل (تحريك، تغيير قيمة، زر...)
  function commit() {
    var s = JSON.stringify(state.layers);
    if (history.idx >= 0 && history.stack[history.idx] === s) return;
    history.stack = history.stack.slice(0, history.idx + 1);
    history.stack.push(s);
    if (history.stack.length > 150) history.stack.shift();
    history.idx = history.stack.length - 1;
    updateHistoryButtons();
  }
  var commitTimer = 0;
  function commitLater() { clearTimeout(commitTimer); commitTimer = setTimeout(commit, 350); }
  function restoreAt(i) {
    history.idx = i;
    state.layers = JSON.parse(history.stack[i]);
    if (!findLayer(state.activeId)) state.activeId = state.layers.length ? state.layers[state.layers.length - 1].id : null;
    refreshAll();
  }
  function undo() {
    clearTimeout(commitTimer); commit();
    if (history.idx > 0) { restoreAt(history.idx - 1); setStatus('تم التراجع.'); }
  }
  function redo() {
    clearTimeout(commitTimer); commit();
    if (history.idx < history.stack.length - 1) { restoreAt(history.idx + 1); setStatus('تمت الإعادة.'); }
  }
  function updateHistoryButtons() {
    $('undo').disabled = history.idx <= 0;
    $('redo').disabled = history.idx >= history.stack.length - 1;
  }

  /* ---------- الهندسة ---------- */
  function geom(l) {
    var im = imgOf(l);
    var ow = l.wf * pw, oh = ow * im.h / im.w;
    var a = l.rot * Math.PI / 180;
    var cx = l.cx * pw, cy = l.cy * ph;
    var hx = cx + (ow / 2) * Math.cos(a) - (oh / 2) * Math.sin(a);
    var hy = cy + (ow / 2) * Math.sin(a) + (oh / 2) * Math.cos(a);
    var bx = (Math.abs(ow * Math.cos(a)) + Math.abs(oh * Math.sin(a))) / 2;
    var by = (Math.abs(ow * Math.sin(a)) + Math.abs(oh * Math.cos(a))) / 2;
    return { cx: cx, cy: cy, ow: ow, oh: oh, a: a, hx: hx, hy: hy, bx: bx, by: by };
  }
  function cssK() {
    var r = $('stage').getBoundingClientRect();
    return r.width ? pw / r.width : 1;
  }

  /* ---------- معالجة الصور ---------- */
  function statsOf(d, minA) {
    var n = 0, s = [0, 0, 0], q = [0, 0, 0], c, i, v;
    for (i = 0; i < d.length; i += 4) {
      if (d[i + 3] < minA) continue;
      n++;
      for (c = 0; c < 3; c++) { v = d[i + c]; s[c] += v; q[c] += v * v; }
    }
    if (n < 16) return null;
    var mean = [], sd = [];
    for (c = 0; c < 3; c++) {
      mean[c] = s[c] / n;
      sd[c] = Math.sqrt(Math.max(0, q[c] / n - mean[c] * mean[c]));
    }
    return { mean: mean, sd: sd };
  }
  function smallCopy(img, longest) {
    var r = Math.min(1, longest / Math.max(img.w, img.h));
    var w = Math.max(1, Math.round(img.w * r)), h = Math.max(1, Math.round(img.h * r));
    var c = newCanvas(w, h);
    var x = c.getContext('2d', { willReadFrequently: true });
    x.imageSmoothingQuality = 'high';
    x.drawImage(img.src, 0, 0, w, h);
    return c;
  }
  function overlayStats(img) {
    var c = smallCopy(img, 128);
    return statsOf(c.getContext('2d').getImageData(0, 0, c.width, c.height).data, 128);
  }
  function baseRegionStats(l) {
    var b = baseImg(), im = imgOf(l);
    if (!b || !b.thumb || !im) return null;
    var t = b.thumb;
    var W = 1000, H = 1000 * b.h / b.w;
    var ow = l.wf * W, oh = ow * im.h / im.w, a = l.rot * Math.PI / 180;
    var hx = (Math.abs(ow * Math.cos(a)) + Math.abs(oh * Math.sin(a))) / 2 * 1.1;
    var hy = (Math.abs(ow * Math.sin(a)) + Math.abs(oh * Math.cos(a))) / 2 * 1.1;
    var x0 = clamp(Math.floor((l.cx * W - hx) / W * t.width), 0, t.width - 1);
    var x1 = clamp(Math.ceil((l.cx * W + hx) / W * t.width), x0 + 1, t.width);
    var y0 = clamp(Math.floor((l.cy * H - hy) / H * t.height), 0, t.height - 1);
    var y1 = clamp(Math.ceil((l.cy * H + hy) / H * t.height), y0 + 1, t.height);
    var d = t.getContext('2d').getImageData(x0, y0, x1 - x0, y1 - y0).data;
    return statsOf(d, 1);
  }
  function buildLut(l) {
    var os = imgOf(l).stats, ts = baseRegionStats(l);
    if (!os || !ts) return null;
    var k = l.match / 100, lut = [];
    for (var c = 0; c < 3; c++) {
      var ratio = clamp(ts.sd[c] / Math.max(os.sd[c], 4), 0.6, 1.6);
      var r = 1 + k * (ratio - 1);
      var mu = os.mean[c] + k * (ts.mean[c] - os.mean[c]);
      var L = new Uint8ClampedArray(256);
      for (var v = 0; v < 256; v++) L[v] = (v - os.mean[c]) * r + mu;
      lut.push(L);
    }
    return lut;
  }
  function blurCanvas(src, r) {
    if (r < 0.3) return src;
    var t = newCanvas(src.width, src.height), c = t.getContext('2d');
    c.imageSmoothingQuality = 'high';
    if (FILTER_OK) {
      c.filter = 'blur(' + r.toFixed(2) + 'px)';
      c.drawImage(src, 0, 0);
    } else {
      var f = 1 / (1 + r);
      var sw = Math.max(1, Math.round(src.width * f)), sh = Math.max(1, Math.round(src.height * f));
      var m = newCanvas(sw, sh), mc = m.getContext('2d');
      mc.imageSmoothingQuality = 'high';
      mc.drawImage(src, 0, 0, sw, sh);
      c.drawImage(m, 0, 0, src.width, src.height);
    }
    return t;
  }
  function noise(x, y) {
    var h = (Math.imul(x, 374761393) + Math.imul(y, 668265263)) | 0;
    h = Math.imul(h ^ (h >>> 13), 1274126177);
    h ^= h >>> 16;
    return (h >>> 0) / 4294967296;
  }
  function pixelPass(cv, lut, feather, grain) {
    if (!lut && feather <= 0 && grain <= 0) return;
    var ctx = cv.getContext('2d', { willReadFrequently: true });
    var w = cv.width, h = cv.height;
    var rows = Math.max(1, Math.floor(4000000 / w));
    for (var y0 = 0; y0 < h; y0 += rows) {
      var hh = Math.min(rows, h - y0);
      var id = ctx.getImageData(0, y0, w, hh), d = id.data;
      for (var y = 0; y < hh; y++) {
        var Y = y0 + y;
        for (var x = 0; x < w; x++) {
          var i = (y * w + x) * 4, a = d[i + 3];
          if (a === 0) continue;
          if (lut) { d[i] = lut[0][d[i]]; d[i + 1] = lut[1][d[i + 1]]; d[i + 2] = lut[2][d[i + 2]]; }
          if (grain > 0) {
            var n = (noise(x, Y) + noise(Y + 7, x + 13) - 1) * grain;
            d[i] += n; d[i + 1] += n; d[i + 2] += n;
          }
          if (feather > 0) {
            var dist = Math.min(x, Y, w - 1 - x, h - 1 - Y);
            if (dist < feather) {
              var t = dist / feather;
              d[i + 3] = a * (t * t * (3 - 2 * t));
            }
          }
        }
      }
      ctx.putImageData(id, 0, y0);
    }
  }

  // كاش لكل طبقة حتى لا تُعاد المعالجة الثقيلة عند كل حركة
  var layerCache = new Map();
  function layerCanvas(l, W, useCache) {
    var im = imgOf(l);
    var ow = Math.max(1, Math.round(l.wf * W));
    var oh = Math.max(1, Math.round(ow * im.h / im.w));
    var key = null;
    if (useCache) {
      key = [W, ow, oh, im.id, l.soft, l.feather, l.grain, l.match,
        l.match > 0 ? [l.cx.toFixed(3), l.cy.toFixed(3), l.rot.toFixed(1)].join() : ''].join('|');
      var hit = layerCache.get(l.id);
      if (hit && hit.key === key) return hit.canvas;
    }
    var c = newCanvas(ow, oh), x = c.getContext('2d');
    x.imageSmoothingEnabled = true;
    x.imageSmoothingQuality = 'high';
    x.drawImage(im.src, 0, 0, ow, oh);
    if (l.soft > 0) c = blurCanvas(c, l.soft / 100 * 0.004 * W);
    var lut = l.match > 0 ? buildLut(l) : null;
    var feather = l.feather > 0 ? l.feather / 100 * 0.25 * Math.min(ow, oh) : 0;
    var grain = l.grain > 0 ? l.grain / 100 * 16 : 0;
    pixelPass(c, lut, feather, grain);
    if (useCache) layerCache.set(l.id, { key: key, canvas: c });
    return c;
  }

  function drawLayer(ctx, W, H, l, useCache) {
    var oc = layerCanvas(l, W, useCache);
    ctx.save();
    ctx.translate(l.cx * W, l.cy * H);
    ctx.rotate(l.rot * Math.PI / 180);
    if (l.flip) ctx.scale(-1, 1);
    ctx.globalAlpha = l.op;
    ctx.globalCompositeOperation = l.blend;
    if (l.shadow > 0) {
      var k = l.shadow / 100, blur = (0.003 + 0.02 * k) * W;
      ctx.shadowColor = 'rgba(0,0,0,' + (0.15 + 0.5 * k).toFixed(3) + ')';
      ctx.shadowBlur = blur;
      ctx.shadowOffsetX = blur * 0.15;
      ctx.shadowOffsetY = blur * 0.4;
    }
    ctx.drawImage(oc, -oc.width / 2, -oc.height / 2);
    ctx.restore();
  }
  function renderScene(ctx, W, H, useCache) {
    var b = baseImg();
    if (!b) return;
    ctx.imageSmoothingEnabled = true;
    ctx.imageSmoothingQuality = 'high';
    ctx.drawImage(b.src, 0, 0, W, H);
    if (state.peek) return;
    for (var i = 0; i < state.layers.length; i++) {
      var l = state.layers[i];
      if (l.visible) drawLayer(ctx, W, H, l, useCache);
    }
  }

  /* ---------- المعاينة ---------- */
  var stage = $('stage');
  var sctx = stage.getContext('2d');

  function layoutPreview() {
    var b = baseImg();
    var longest = Math.max(b.w, b.h);
    var target = clamp(longest, 1000, 1800);
    var f = target / longest;
    var w = Math.max(1, Math.round(b.w * f));
    var h = Math.max(1, Math.round(b.h * f));
    if (stage.width !== w || stage.height !== h) { stage.width = w; stage.height = h; }
    stage.style.setProperty('--ar', (b.w / b.h).toFixed(5));
    pw = w; ph = h;
  }
  function drawFrame(l) {
    var g = geom(l), k = cssK();
    sctx.save();
    sctx.translate(g.cx, g.cy);
    sctx.rotate(g.a);
    sctx.setLineDash([]);
    sctx.strokeStyle = 'rgba(0,0,0,0.35)';
    sctx.lineWidth = 2 * k;
    sctx.strokeRect(-g.ow / 2, -g.oh / 2, g.ow, g.oh);
    sctx.strokeStyle = 'rgba(255,255,255,0.9)';
    sctx.lineWidth = 1 * k;
    sctx.strokeRect(-g.ow / 2, -g.oh / 2, g.ow, g.oh);
    sctx.restore();
    if (l.locked) return;
    sctx.beginPath();
    sctx.arc(g.hx, g.hy, 5 * k, 0, Math.PI * 2);
    sctx.fillStyle = 'rgba(255,255,255,0.95)';
    sctx.fill();
    sctx.lineWidth = 1 * k;
    sctx.strokeStyle = 'rgba(0,0,0,0.5)';
    sctx.stroke();
  }
  function drawGuides() {
    if (!snap.x && !snap.y) return;
    var k = cssK();
    sctx.save();
    sctx.setLineDash([6 * k, 4 * k]);
    sctx.strokeStyle = 'rgba(76,201,212,0.95)';
    sctx.lineWidth = 1.5 * k;
    sctx.beginPath();
    if (snap.x) { sctx.moveTo(pw / 2, 0); sctx.lineTo(pw / 2, ph); }
    if (snap.y) { sctx.moveTo(0, ph / 2); sctx.lineTo(pw, ph / 2); }
    sctx.stroke();
    sctx.restore();
  }
  var raf = 0;
  function drawNow() {
    raf = 0;
    if (!baseImg()) return;
    sctx.clearRect(0, 0, pw, ph);
    renderScene(sctx, pw, ph, true);
    if (state.peek) return;
    var a = active();
    if (a && a.visible && state.frame) drawFrame(a);
    if (state.guides) drawGuides();
  }
  function draw() { if (!raf) raf = requestAnimationFrame(drawNow); }

  /* ---------- الإدخال على المعاينة ---------- */
  function toCanvas(e) {
    var r = stage.getBoundingClientRect();
    return { x: (e.clientX - r.left) * pw / r.width, y: (e.clientY - r.top) * ph / r.height };
  }
  function inside(l, p) {
    var g = geom(l), dx = p.x - g.cx, dy = p.y - g.cy;
    var lx = dx * Math.cos(-g.a) - dy * Math.sin(-g.a);
    var ly = dx * Math.sin(-g.a) + dy * Math.cos(-g.a);
    return Math.abs(lx) <= g.ow / 2 && Math.abs(ly) <= g.oh / 2;
  }
  // يرجع الطبقة المضغوطة وطريقة التفاعل: move | scale | select (للمقفلة)
  function hitTest(p) {
    var a = active();
    if (a && a.visible && state.frame && !a.locked) {
      var g = geom(a), k = cssK();
      if (Math.hypot(p.x - g.hx, p.y - g.hy) <= 22 * k) return { layer: a, mode: 'scale' };
    }
    for (var i = state.layers.length - 1; i >= 0; i--) {
      var l = state.layers[i];
      if (!l.visible) continue;
      if (inside(l, p)) return { layer: l, mode: l.locked ? 'select' : 'move' };
    }
    return null;
  }
  function pinchDist() {
    var pts = Array.from(pointers.values());
    return Math.hypot(pts[0].x - pts[1].x, pts[0].y - pts[1].y) || 1;
  }
  function fineK(e) { return (state.fine || (e && e.shiftKey)) ? 0.2 : 1; }

  var pointers = new Map();
  var mode = null, dragLayer = null, dragged = false;
  var startP = null, startCx = 0, startCy = 0, startWf = 0, startDist = 1;

  stage.addEventListener('pointerdown', function (e) {
    if (!baseImg() || state.peek) return;
    pointers.set(e.pointerId, { x: e.clientX, y: e.clientY });
    try { stage.setPointerCapture(e.pointerId); } catch (err) {}
    dragged = false;
    if (pointers.size === 2) {
      var a = active();
      if (a && a.visible && !a.locked) { mode = 'pinch'; dragLayer = a; startDist = pinchDist(); startWf = a.wf; }
      else { mode = null; dragLayer = null; }
    } else if (pointers.size === 1) {
      var p = toCanvas(e), hit = hitTest(p);
      if (!hit) { mode = null; dragLayer = null; return; }
      setActive(hit.layer.id);
      mode = hit.mode; dragLayer = hit.layer;
      startP = p; startCx = dragLayer.cx; startCy = dragLayer.cy; startWf = dragLayer.wf;
      if (mode === 'scale') {
        var g = geom(dragLayer);
        startDist = Math.hypot(p.x - g.cx, p.y - g.cy) || 1;
      }
    }
    if (mode && mode !== 'select') e.preventDefault();
  });

  stage.addEventListener('pointermove', function (e) {
    if (!baseImg()) return;
    if (!pointers.has(e.pointerId)) {
      var h = hitTest(toCanvas(e));
      stage.style.cursor = !h ? 'default' : h.mode === 'scale' ? 'nwse-resize' : h.mode === 'move' ? 'grab' : 'pointer';
      return;
    }
    pointers.set(e.pointerId, { x: e.clientX, y: e.clientY });
    if (!dragLayer) return;
    if (mode === 'pinch' && pointers.size >= 2) {
      dragLayer.wf = clamp(startWf * Math.pow(pinchDist() / startDist, fineK(e)), 0.01, 3);
      dragged = true; changed();
    } else if (mode === 'move' && pointers.size === 1) {
      var p = toCanvas(e), k = fineK(e);
      var nx = clamp(startCx + (p.x - startP.x) * k / pw, 0, 1);
      var ny = clamp(startCy + (p.y - startP.y) * k / ph, 0, 1);
      snap.x = Math.abs(nx - 0.5) < SNAP; if (snap.x) nx = 0.5;
      snap.y = Math.abs(ny - 0.5) < SNAP; if (snap.y) ny = 0.5;
      dragLayer.cx = nx; dragLayer.cy = ny;
      stage.style.cursor = 'grabbing';
      dragged = true; changed();
    } else if (mode === 'scale' && pointers.size === 1) {
      var q = toCanvas(e), g2 = geom(dragLayer);
      var d = Math.hypot(q.x - g2.cx, q.y - g2.cy);
      dragLayer.wf = clamp(startWf * Math.pow(d / startDist, fineK(e)), 0.01, 3);
      dragged = true; changed();
    }
  });

  function endPointer(e) {
    pointers.delete(e.pointerId);
    if (pointers.size === 0) {
      if (mode && mode !== 'select' && dragged) commit();
      mode = null; dragLayer = null;
      snap.x = snap.y = false;
      stage.style.cursor = 'default';
      draw();
    } else if (pointers.size === 1 && mode === 'pinch') {
      if (dragged) commit();
      mode = null; dragLayer = null;
    }
  }
  stage.addEventListener('pointerup', endPointer);
  stage.addEventListener('pointercancel', endPointer);

  stage.addEventListener('wheel', function (e) {
    if (!baseImg()) return;
    var h = hitTest(toCanvas(e));
    if (!h || h.mode === 'select') return;
    e.preventDefault();
    setActive(h.layer.id);
    h.layer.wf = clamp(h.layer.wf * Math.exp(-e.deltaY * 0.0015 * fineK(e)), 0.01, 3);
    changed(); commitLater();
  }, { passive: false });

  stage.addEventListener('keydown', function (e) {
    var a = active();
    if (!a || a.locked) return;
    var step = e.shiftKey ? 0.02 : 0.005, used = true;
    if (e.key === 'ArrowLeft') a.cx = clamp(a.cx - step, 0, 1);
    else if (e.key === 'ArrowRight') a.cx = clamp(a.cx + step, 0, 1);
    else if (e.key === 'ArrowUp') a.cy = clamp(a.cy - step, 0, 1);
    else if (e.key === 'ArrowDown') a.cy = clamp(a.cy + step, 0, 1);
    else if (e.key === '+' || e.key === '=') a.wf = clamp(a.wf * (e.shiftKey ? 1.002 : 1.01), 0.01, 3);
    else if (e.key === '-') a.wf = clamp(a.wf / (e.shiftKey ? 1.002 : 1.01), 0.01, 3);
    else used = false;
    if (used) { e.preventDefault(); changed(); commitLater(); }
  });

  /* ---------- اختصارات لوحة المفاتيح ---------- */
  function isTyping(t) {
    if (!t) return false;
    if (t.tagName === 'SELECT' || t.tagName === 'TEXTAREA') return true;
    return t.tagName === 'INPUT' && t.type !== 'checkbox' && t.type !== 'range' && t.type !== 'file';
  }
  document.addEventListener('keydown', function (e) {
    var mod = e.ctrlKey || e.metaKey, key = e.key.toLowerCase();
    if (mod && key === 'z' && !isTyping(e.target)) { e.preventDefault(); e.shiftKey ? redo() : undo(); return; }
    if (mod && key === 'y' && !isTyping(e.target)) { e.preventDefault(); redo(); return; }
    if (isTyping(e.target)) return;
    if (mod && key === 'd') { e.preventDefault(); duplicateActive(); return; }
    if (key === 'h') { if (!e.repeat) setPeek(true); return; }
    if (e.key === 'Delete') { e.preventDefault(); deleteActive(); return; }
    if (e.key === ']') { moveActive(1); return; }
    if (e.key === '[') { moveActive(-1); return; }
  });
  document.addEventListener('keyup', function (e) {
    if (e.key.toLowerCase() === 'h') setPeek(false);
  });
  window.addEventListener('blur', function () { setPeek(false); });

  function setPeek(on) {
    if (state.peek === on) return;
    state.peek = on;
    $('peek').classList.toggle('on', on);
    draw();
  }
  var peekBtn = $('peek');
  peekBtn.addEventListener('pointerdown', function (e) { e.preventDefault(); setPeek(true); });
  ['pointerup', 'pointerleave', 'pointercancel'].forEach(function (ev) {
    peekBtn.addEventListener(ev, function () { setPeek(false); });
  });

  /* ---------- تحديث الواجهة ---------- */
  function setActive(id) {
    if (state.activeId === id) return;
    state.activeId = id;
    renderLayers();
    syncControls();
    draw();
  }
  function changed() { syncControls(); draw(); }

  function syncControls() {
    var a = active();
    $('layerControls').disabled = !a;
    if (!a) {
      $('rotOut').textContent = '—'; $('opOut').textContent = '—';
      return;
    }
    if (document.activeElement !== $('sizeNum')) $('sizeNum').value = (a.wf * 100).toFixed(1);
    $('size').value = (a.wf * 100).toFixed(1);
    $('rot').value = a.rot;
    $('rotOut').textContent = Math.round(a.rot) + '°';
    $('op').value = Math.round(a.op * 100);
    $('opOut').textContent = Math.round(a.op * 100) + '%';
    $('blend').value = a.blend;
    ENH.forEach(function (k) {
      $(k).value = a[k];
      $(k + 'Out').textContent = Math.round(a[k]) + '%';
    });
    $('frame').checked = state.frame;
    $('guides').checked = state.guides;
    $('fine').checked = state.fine;
    $('layerUp').disabled = state.layers.indexOf(a) === state.layers.length - 1;
    $('layerDown').disabled = state.layers.indexOf(a) === 0;
  }

  function drawThumb(cv, img) {
    var s = cv.width, c = cv.getContext('2d');
    c.clearRect(0, 0, s, s);
    var r = Math.max(s / img.w, s / img.h);
    var w = img.w * r, h = img.h * r;
    c.imageSmoothingQuality = 'high';
    c.drawImage(img.src, (s - w) / 2, (s - h) / 2, w, h);
  }

  function renderLayers() {
    var ul = $('layers');
    ul.innerHTML = '';
    if (!state.layers.length) {
      var empty = document.createElement('li');
      empty.className = 'layers-empty';
      empty.textContent = 'لا توجد طبقات بعد. أضف صورة من الزر أعلاه.';
      ul.appendChild(empty);
    }
    for (var i = state.layers.length - 1; i >= 0; i--) {
      var l = state.layers[i], im = imgOf(l);
      var li = document.createElement('li');
      li.className = 'layer' + (l.id === state.activeId ? ' active' : '') + (l.visible ? '' : ' off');
      li.setAttribute('data-id', l.id);

      var pick = document.createElement('button');
      pick.type = 'button';
      pick.className = 'lpick';
      pick.setAttribute('data-action', 'pick');
      pick.setAttribute('aria-current', l.id === state.activeId ? 'true' : 'false');
      var th = document.createElement('canvas');
      th.className = 'lthumb'; th.width = 40; th.height = 40;
      if (im) drawThumb(th, im);
      var nm = document.createElement('span');
      nm.className = 'lname';
      nm.setAttribute('dir', 'auto');
      nm.textContent = l.name;
      pick.appendChild(th);
      pick.appendChild(nm);

      var vis = document.createElement('button');
      vis.type = 'button'; vis.className = 'ibtn';
      vis.setAttribute('data-action', 'vis');
      vis.setAttribute('aria-label', l.visible ? 'إخفاء الطبقة' : 'إظهار الطبقة');
      vis.title = l.visible ? 'إخفاء' : 'إظهار';
      vis.textContent = l.visible ? '👁' : '🙈';

      var lock = document.createElement('button');
      lock.type = 'button'; lock.className = 'ibtn';
      lock.setAttribute('data-action', 'lock');
      lock.setAttribute('aria-label', l.locked ? 'فتح قفل الطبقة' : 'قفل الطبقة');
      lock.title = l.locked ? 'مقفلة (اضغط للفتح)' : 'قفل الموضع';
      lock.textContent = l.locked ? '🔒' : '🔓';

      li.appendChild(pick);
      li.appendChild(vis);
      li.appendChild(lock);
      ul.appendChild(li);
    }
    updateLayerButtons();
  }
  function updateLayerButtons() {
    var has = !!active();
    ['layerDup', 'layerDel'].forEach(function (id) { $(id).disabled = !has; });
    $('layerUp').disabled = !has || state.layers.indexOf(active()) === state.layers.length - 1;
    $('layerDown').disabled = !has || state.layers.indexOf(active()) === 0;
  }

  function updateSlot() {
    var b = baseImg();
    if (!b) return;
    drawThumb($('thumbBase'), b);
    var meta = $('metaBase');
    meta.innerHTML = '';
    var label = document.createElement('span');
    label.setAttribute('dir', 'auto');
    label.textContent = displayName(b);
    meta.appendChild(label);
    meta.appendChild(document.createTextNode(' · '));
    var d = document.createElement('span');
    d.className = 'num';
    d.textContent = b.w + ' × ' + b.h + ' px';
    meta.appendChild(d);
    meta.title = b.sample ? '' : b.name;
  }

  function updateOutputOptions() {
    var sel = $('mult'), b = baseImg();
    if (!b) return;
    var html = '';
    [1, 2, 3, 4].forEach(function (m) {
      var W = b.w * m, H = b.h * m;
      var ok = m === 1 || (W <= MAX_SIDE && H <= MAX_SIDE && W * H <= MAX_AREA);
      var name = m === 1 ? 'الأصلية ×1' : '×' + m;
      html += '<option value="' + m + '"' + (ok ? '' : ' disabled') + '>' + name + ' · ⁦' + W + ' × ' + H + '⁩</option>';
    });
    sel.innerHTML = html;
    if (state.mult > 1 && sel.querySelector('option[value="' + state.mult + '"]:disabled')) state.mult = 1;
    sel.value = String(state.mult);
  }
  function updateSaveEnabled() {
    $('save').disabled = !(downloads && baseImg());
  }
  function refreshAll() {
    renderLayers();
    syncControls();
    updateSaveEnabled();
    updateHistoryButtons();
    draw();
  }

  /* ---------- تحميل الصور ---------- */
  async function decode(file) {
    var bmp = null;
    try {
      bmp = await createImageBitmap(file, { imageOrientation: 'from-image' });
    } catch (e) {
      bmp = await new Promise(function (res, rej) {
        var img = new Image();
        var url = URL.createObjectURL(file);
        img.onload = function () { res(img); };
        img.onerror = function () { rej(new Error('decode')); };
        img.src = url;
      });
    }
    var w = bmp.width || bmp.naturalWidth, h = bmp.height || bmp.naturalHeight;
    if (!w || !h) throw new Error('empty');
    return { src: bmp, w: w, h: h, name: file.name || 'صورة' };
  }
  function register(im) {
    im.id = ++imgSeq;
    im.stats = overlayStats(im);
    images.set(im.id, im);
    return im;
  }
  async function loadImage(file) {
    if (!isImageFile(file)) throw new Error('type');
    return register(await decode(file));
  }

  function setBase(im) {
    state.baseId = im.id;
    im.thumb = smallCopy(im, 200);
    layoutPreview();
    updateSlot();
    updateOutputOptions();
    $('stageEmpty').hidden = true;
    stage.hidden = false;
    refreshAll();
  }

  function fitLayerToBase(l, im) {
    var b = baseImg();
    var maxByHeight = b ? 0.6 * (b.h / b.w) * (im.w / im.h) : 0.4;
    l.wf = clamp(Math.min(0.4, maxByHeight), 0.05, 1);
  }
  function addLayer(im) {
    var n = state.layers.length % 5;
    var l = Object.assign({}, LAYER_DEFAULTS, {
      id: ++layerSeq, imgId: im.id, name: displayName(im),
      cx: clamp(0.5 + 0.03 * (n - 2), 0, 1), cy: clamp(0.5 + 0.03 * (n - 2), 0, 1)
    });
    fitLayerToBase(l, im);
    state.layers.push(l);
    state.activeId = l.id;
    return l;
  }

  async function addFiles(files) {
    var list = files.filter(isImageFile);
    if (!list.length) { setStatus('اختر ملف صورة (JPG أو PNG أو WebP).', 'err'); return; }
    var added = 0, failed = 0;
    setStatus('جارٍ فتح الصور…');
    for (var i = 0; i < list.length; i++) {
      try {
        var im = await loadImage(list[i]);
        if (!baseImg()) setBase(im); else addLayer(im);
        added++;
      } catch (e) { failed++; }
    }
    if (added) commit();
    refreshAll();
    if (failed && !added) setStatus('تعذّر فتح هذه الصور. جرّب JPG أو PNG أو WebP.', 'err');
    else if (failed) setStatus('أُضيفت ' + added + ' وتعذّر فتح ' + failed + '.', 'err');
    else setStatus(added === 1 ? 'أُضيفت الطبقة.' : 'أُضيفت ' + added + ' طبقات.', 'ok');
  }
  async function setBaseFromFile(file) {
    setStatus('جارٍ فتح الصورة…');
    try {
      setBase(await loadImage(file));
      setStatus('');
    } catch (e) { setStatus('تعذّر فتح هذه الصورة. جرّب JPG أو PNG أو WebP.', 'err'); }
  }

  /* ---------- عمليات الطبقات ---------- */
  function deleteActive() {
    var a = active();
    if (!a) return;
    var idx = state.layers.indexOf(a);
    state.layers.splice(idx, 1);
    layerCache.delete(a.id);
    var top = state.layers[Math.min(idx, state.layers.length - 1)];
    state.activeId = top ? top.id : null;
    commit(); refreshAll();
    setStatus('حُذفت الطبقة. يمكنك التراجع بـ Ctrl+Z.');
  }
  function duplicateActive() {
    var a = active();
    if (!a) return;
    var c = Object.assign({}, a, {
      id: ++layerSeq, name: a.name + ' (نسخة)',
      cx: clamp(a.cx + 0.03, 0, 1), cy: clamp(a.cy + 0.03, 0, 1), locked: false
    });
    state.layers.splice(state.layers.indexOf(a) + 1, 0, c);
    state.activeId = c.id;
    commit(); refreshAll();
    setStatus('تم تكرار الطبقة.');
  }
  function moveActive(dir) {
    var a = active();
    if (!a) return;
    var i = state.layers.indexOf(a), j = i + dir;
    if (j < 0 || j >= state.layers.length) return;
    state.layers[i] = state.layers[j];
    state.layers[j] = a;
    commit(); refreshAll();
  }
  function resetActive() {
    var a = active();
    if (!a) return;
    Object.assign(a, LAYER_DEFAULTS, { id: a.id, imgId: a.imgId, name: a.name, visible: a.visible, locked: a.locked });
    fitLayerToBase(a, imgOf(a));
    commit(); refreshAll();
  }
  function alignActive(where) {
    var a = active(), b = baseImg();
    if (!a || !b) return;
    if (a.locked) { setStatus('الطبقة مقفلة. افتح قفلها أولًا.', 'err'); return; }
    var g = geom(a);
    if (where === 'hcenter') a.cx = 0.5;
    else if (where === 'vcenter') a.cy = 0.5;
    else if (where === 'left') a.cx = clamp(g.bx / pw, 0, 1);
    else if (where === 'right') a.cx = clamp(1 - g.bx / pw, 0, 1);
    else if (where === 'top') a.cy = clamp(g.by / ph, 0, 1);
    else if (where === 'bottom') a.cy = clamp(1 - g.by / ph, 0, 1);
    changed(); commit();
  }
  function applyPreset(id) {
    var a = active(), p = PRESETS.filter(function (x) { return x.id === id; })[0];
    if (!a || !p) { setStatus('اختر طبقة أولًا.', 'err'); return; }
    a.op = p.op; a.blend = p.blend;
    ENH.forEach(function (k) { a[k] = p[k]; });
    commit(); refreshAll();
    setStatus('طُبّق القالب «' + p.label + '».', 'ok');
  }

  /* ---------- أحداث اللوحة ---------- */
  function bindSlider(id, apply) {
    var el = $(id);
    el.addEventListener('input', function () {
      var a = active();
      if (!a) return;
      apply(a, parseFloat(el.value));
      changed();
    });
    el.addEventListener('change', commit);
  }
  bindSlider('size', function (a, v) { a.wf = clamp(v / 100, 0.01, 3); });
  bindSlider('rot', function (a, v) { a.rot = v; });
  bindSlider('op', function (a, v) { a.op = v / 100; });
  ENH.forEach(function (k) { bindSlider(k, function (a, v) { a[k] = v; }); });

  $('sizeNum').addEventListener('input', function (e) {
    var a = active(), v = parseFloat(e.target.value);
    if (!a || !isFinite(v)) return;
    a.wf = clamp(v / 100, 0.01, 3);
    changed();
  });
  $('sizeNum').addEventListener('change', function () { commit(); syncControls(); });
  $$('[data-step]').forEach(function (b) {
    b.addEventListener('click', function () {
      var a = active();
      if (!a) return;
      var step = parseFloat(b.getAttribute('data-step'));
      a.wf = clamp(Math.round((a.wf * 100 + step) * 10) / 10 / 100, 0.01, 3);
      changed(); commit();
    });
  });

  $('blend').addEventListener('change', function (e) {
    var a = active(); if (!a) return;
    a.blend = e.target.value; changed(); commit();
  });
  $('flip').addEventListener('click', function () {
    var a = active(); if (!a) return;
    a.flip = !a.flip; changed(); commit();
  });
  $('fit').addEventListener('click', function () {
    var a = active(); if (!a) return;
    fitLayerToBase(a, imgOf(a)); changed(); commit();
  });
  $('resetLayer').addEventListener('click', resetActive);
  $$('[data-align]').forEach(function (b) {
    b.addEventListener('click', function () { alignActive(b.getAttribute('data-align')); });
  });
  $('autoEnhance').addEventListener('click', function () {
    var a = active(); if (!a) return;
    ENH.forEach(function (k) { a[k] = AUTO[k]; });
    changed(); commit();
  });
  $('noEnhance').addEventListener('click', function () {
    var a = active(); if (!a) return;
    ENH.forEach(function (k) { a[k] = 0; });
    changed(); commit();
  });

  // قائمة القوالب
  (function () {
    var sel = $('preset');
    sel.innerHTML = '<option value="">— اختر قالبًا —</option>' + PRESETS.map(function (p) {
      return '<option value="' + p.id + '">' + p.label + '</option>';
    }).join('');
  })();
  $('applyPreset').addEventListener('click', function () { applyPreset($('preset').value); });

  // أزرار الطبقات
  $('layerUp').addEventListener('click', function () { moveActive(1); });
  $('layerDown').addEventListener('click', function () { moveActive(-1); });
  $('layerDup').addEventListener('click', duplicateActive);
  $('layerDel').addEventListener('click', deleteActive);
  $('undo').addEventListener('click', undo);
  $('redo').addEventListener('click', redo);

  // قائمة الطبقات (تفويض الأحداث)
  $('layers').addEventListener('click', function (e) {
    var li = e.target.closest('li.layer');
    if (!li) return;
    var id = parseInt(li.getAttribute('data-id'), 10);
    var l = findLayer(id);
    if (!l) return;
    var btn = e.target.closest('button');
    var act = btn ? btn.getAttribute('data-action') : 'pick';
    if (act === 'vis') { l.visible = !l.visible; commit(); state.activeId = id; refreshAll(); return; }
    if (act === 'lock') { l.locked = !l.locked; commit(); state.activeId = id; refreshAll(); return; }
    setActive(id);
    renderLayers();
  });

  // الخيارات العامة
  $('frame').addEventListener('change', function (e) { state.frame = e.target.checked; draw(); });
  $('guides').addEventListener('change', function (e) { state.guides = e.target.checked; draw(); });
  $('fine').addEventListener('change', function (e) { state.fine = e.target.checked; });
  $('format').addEventListener('change', function (e) {
    state.format = e.target.value;
    $('formatNote').textContent = FORMAT_NOTES[state.format];
  });
  $('mult').addEventListener('change', function (e) { state.mult = parseInt(e.target.value, 10) || 1; });
  window.addEventListener('resize', function () { if (baseImg()) draw(); });

  // الصور: زر التغيير، الإضافة، والسحب والإفلات
  $('pickBase').addEventListener('click', function () { $('fileBase').click(); });
  $('fileBase').addEventListener('change', function (e) {
    var f = e.target.files && e.target.files[0];
    e.target.value = '';
    if (f) setBaseFromFile(f);
  });
  $('addLayer').addEventListener('click', function () { $('fileLayer').click(); });
  $('fileLayer').addEventListener('change', function (e) {
    var files = Array.prototype.slice.call(e.target.files || []);
    e.target.value = '';
    addFiles(files);
  });

  var dz = $('dropzone');
  window.addEventListener('dragover', function (e) { e.preventDefault(); });
  window.addEventListener('drop', function (e) { e.preventDefault(); });
  dz.addEventListener('dragover', function (e) { e.preventDefault(); dz.classList.add('drag'); });
  dz.addEventListener('dragleave', function () { dz.classList.remove('drag'); });
  dz.addEventListener('drop', function (e) {
    dz.classList.remove('drag');
    addFiles(Array.prototype.slice.call((e.dataTransfer && e.dataTransfer.files) || []));
  });
  var slotBase = $('slotBase');
  slotBase.addEventListener('dragover', function (e) { e.preventDefault(); slotBase.classList.add('drag'); });
  slotBase.addEventListener('dragleave', function () { slotBase.classList.remove('drag'); });
  slotBase.addEventListener('drop', function (e) {
    e.preventDefault(); e.stopPropagation();
    slotBase.classList.remove('drag');
    var f = e.dataTransfer && e.dataTransfer.files && e.dataTransfer.files[0];
    if (f) setBaseFromFile(f);
  });

  /* ---------- صور المثال ---------- */
  function makeSampleBase() {
    var W = 2400, H = 1600;
    var c = newCanvas(W, H), x = c.getContext('2d');
    var sky = x.createLinearGradient(0, 0, 0, H);
    sky.addColorStop(0, '#2B4C7E');
    sky.addColorStop(0.55, '#E58E73');
    sky.addColorStop(1, '#F6D6A4');
    x.fillStyle = sky; x.fillRect(0, 0, W, H);
    var sun = x.createRadialGradient(1700, 820, 20, 1700, 820, 260);
    sun.addColorStop(0, '#FFF6D6'); sun.addColorStop(1, 'rgba(255,230,170,0)');
    x.fillStyle = sun; x.beginPath(); x.arc(1700, 820, 260, 0, Math.PI * 2); x.fill();
    x.fillStyle = '#FFF2C4'; x.beginPath(); x.arc(1700, 820, 90, 0, Math.PI * 2); x.fill();
    var layers = [
      { y: 980, amp: 90, color: '#7A5C7E' },
      { y: 1120, amp: 120, color: '#4E4A74' },
      { y: 1290, amp: 150, color: '#2B3A55' },
      { y: 1440, amp: 110, color: '#18243A' }
    ];
    layers.forEach(function (l, i) {
      x.fillStyle = l.color;
      x.beginPath();
      x.moveTo(0, H);
      x.lineTo(0, l.y);
      for (var px = 0; px <= W; px += 40) {
        var py = l.y + Math.sin(px / 260 + i * 1.7) * l.amp * 0.5 + Math.sin(px / 110 + i) * l.amp * 0.25;
        x.lineTo(px, py);
      }
      x.lineTo(W, H);
      x.closePath();
      x.fill();
    });
    return { src: c, w: W, h: H, name: 'sample-base', sample: true };
  }
  function makeSampleOver() {
    var S = 800;
    var c = newCanvas(S, S), x = c.getContext('2d');
    var g = x.createLinearGradient(0, 0, S, S);
    g.addColorStop(0, '#12B5C2'); g.addColorStop(1, '#0B5F8A');
    x.fillStyle = g;
    x.beginPath(); x.arc(S / 2, S / 2, 360, 0, Math.PI * 2); x.fill();
    x.lineWidth = 18; x.strokeStyle = 'rgba(255,255,255,0.9)';
    x.beginPath(); x.arc(S / 2, S / 2, 330, 0, Math.PI * 2); x.stroke();
    x.fillStyle = '#FFFFFF';
    x.textAlign = 'center'; x.textBaseline = 'middle';
    x.direction = 'rtl';
    x.font = '700 190px "Reem Kufi", "Segoe UI", Tahoma, sans-serif';
    x.fillText('طبقتي', S / 2, S / 2 - 20);
    x.font = '500 60px "IBM Plex Sans Arabic", "Segoe UI", Tahoma, sans-serif';
    x.globalAlpha = 0.85;
    x.fillText('صورة مثال', S / 2, S / 2 + 140);
    return { src: c, w: S, h: S, name: 'sample-overlay', sample: true };
  }

  /* ---------- التصدير ---------- */
  function fileStem() {
    var b = baseImg();
    if (!b || b.sample) return 'merged-image';
    var s = b.name.replace(/\.[^.]+$/, '').replace(/[^\w؀-ۿ\- ]+/g, '_').trim().slice(0, 60);
    return (s || 'image') + '-merged';
  }

  $('save').addEventListener('click', async function () {
    if (!downloads || !baseImg()) return;
    var btn = $('save');
    btn.disabled = true;
    setStatus('جارٍ تجهيز الملف بأعلى جودة…');
    await new Promise(function (r) { setTimeout(r, 40); });
    var c = null;
    try {
      var b = baseImg(), k = state.mult, W = b.w * k, H = b.h * k;
      c = newCanvas(W, H);
      var ctx = c.getContext('2d');
      if (!ctx) throw new Error('ctx');
      if (state.format === 'jpeg') { ctx.fillStyle = '#FFFFFF'; ctx.fillRect(0, 0, W, H); }
      renderScene(ctx, W, H, false);
      var blob = await new Promise(function (res) { c.toBlob(res, MIME[state.format], 1); });
      if (!blob || !blob.size) throw new Error('toolarge');
      var ext = EXT[blob.type] || 'png';
      var res = await downloads.save({ filename: fileStem() + '.' + ext, data: blob });
      if (res && res.status === 'saved') {
        setStatus('تم الحفظ: ' + W + ' × ' + H + ' بكسل، ' + fmtSize(blob.size) + '.', 'ok');
      } else {
        setStatus('');
      }
    } catch (err) {
      var code = err && err.code;
      if (code === 'declined') setStatus('أُلغي الحفظ.');
      else if (code === 'rate_limited') setStatus('هناك نافذة حفظ مفتوحة. أغلقها ثم حاول مرة أخرى.', 'err');
      else if (code === 'too_large') setStatus('الملف كبير جدًا. اختر دقة أقل ثم حاول مرة أخرى.', 'err');
      else if (err && err.message === 'toolarge') setStatus('هذه الدقة كبيرة على هذا الجهاز. اختر دقة أقل (×1 مثلًا).', 'err');
      else setStatus('تعذّر حفظ الصورة. حاول مرة أخرى.', 'err');
    } finally {
      if (c) { c.width = 0; c.height = 0; }
      updateSaveEnabled();
    }
  });

  /* ---------- البدء ---------- */
  $('formatNote').textContent = FORMAT_NOTES[state.format];
  updateHistoryButtons();

  (async function () {
    try {
      // مكان حفظ الملف: Claude، أو تطبيق أندرويد عبر نافذة المشاركة، أو تنزيل المتصفح
      var claude = window.claude;
      if (claude && claude.use) {
        downloads = await claude.use('downloads');
      } else if (window.Capacitor && window.Capacitor.isNativePlatform && window.Capacitor.isNativePlatform()) {
        downloads = {
          save: function (req) {
            return new Promise(function (resolve, reject) {
              var fr = new FileReader();
              fr.onerror = function () { reject(new Error('read')); };
              fr.onload = async function () {
                try {
                  var P = window.Capacitor.Plugins;
                  var b64 = String(fr.result).split(',')[1];
                  var name = 'overlay-' + Date.now() + '-' + req.filename;
                  await P.Filesystem.writeFile({ path: name, data: b64, directory: 'CACHE', recursive: true });
                  var uri = await P.Filesystem.getUri({ path: name, directory: 'CACHE' });
                  await P.Share.share({ title: req.filename, files: [uri.uri] });
                  resolve({ status: 'saved' });
                } catch (e) { reject(e); }
              };
              fr.readAsDataURL(req.data);
            });
          }
        };
      } else {
        downloads = {
          save: function (req) {
            return new Promise(function (resolve) {
              var url = URL.createObjectURL(req.data);
              var a = document.createElement('a');
              a.href = url;
              a.download = req.filename;
              document.body.appendChild(a);
              a.click();
              a.remove();
              setTimeout(function () { URL.revokeObjectURL(url); }, 60000);
              resolve({ status: 'saved' });
            });
          }
        };
      }
    } catch (e) { downloads = null; }
    $('noDl').hidden = !!downloads;
    updateSaveEnabled();
  })();

  (async function () {
    try {
      if (document.fonts && document.fonts.load) {
        await Promise.race([
          Promise.all([document.fonts.load('700 120px "Reem Kufi"'), document.fonts.load('500 60px "IBM Plex Sans Arabic"')]),
          new Promise(function (r) { setTimeout(r, 1500); })
        ]);
      }
    } catch (e) {}
    if (!baseImg()) {
      var sb = register(makeSampleBase());
      setBase(sb);
    }
    if (!state.layers.length) {
      var so = register(makeSampleOver());
      addLayer(so);
    }
    commit();
    refreshAll();
  })();
})();
