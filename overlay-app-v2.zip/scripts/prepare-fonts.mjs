// Copies the Arabic fonts from the @fontsource packages into www/fonts
// so the app never needs Google Fonts (or any network) at runtime.
import fs from 'node:fs';
import path from 'node:path';

const OUT = path.join('www', 'fonts');
const FONTS = [
  { pkg: 'ibm-plex-sans-arabic', weights: [400, 500, 600] },
  { pkg: 'reem-kufi', weights: [500, 700] },
];

fs.mkdirSync(OUT, { recursive: true });
let css = '';

for (const { pkg, weights } of FONTS) {
  const base = path.join('node_modules', '@fontsource', pkg);
  for (const w of weights) {
    const cssFile = path.join(base, `${w}.css`);
    if (!fs.existsSync(cssFile)) throw new Error(`Missing ${cssFile}`);
    let src = fs.readFileSync(cssFile, 'utf8');
    // Rewrite url(./files/x.woff2) -> url(x.woff2) and copy the file next to fonts.css
    src = src.replace(/url\(\.\/files\/([^)]+)\)/g, (_, file) => {
      fs.copyFileSync(path.join(base, 'files', file), path.join(OUT, file));
      return `url(${file})`;
    });
    css += src + '\n';
  }
}

fs.writeFileSync(path.join(OUT, 'fonts.css'), css);
console.log('Fonts ready in', OUT);
